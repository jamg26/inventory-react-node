module.exports = {
  // mongoURI:"mongodb+srv://accounting_users:Du42wJ8awNot157R@accounting-ium1e.gcp.mongodb.net/shop",
  // mongoURI: "mongodb://auth-mongo-srv:27017/auth",
  mongoURI: "mongodb://localhost/shop",
  sub: "/products/api",
};
