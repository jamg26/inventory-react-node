module.exports = {
  // mongoURI:"mongodb+srv://accounting_users:Du42wJ8awNot157R@accounting-ium1e.gcp.mongodb.net/shop",
  // mongoURI: "mongodb://auth-mongo-srv:27017/auths",
  mongoURI: "mongodb://localhost/shop",
  sub: "/customers/api",
};
